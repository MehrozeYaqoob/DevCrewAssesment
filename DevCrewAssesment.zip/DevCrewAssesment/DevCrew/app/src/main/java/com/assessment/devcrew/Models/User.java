package com.assessment.devcrew.Models;

/**
 * Created by mr on 03/03/16.
 */
public class User {

    private String firstName;
    private String lastName;

    public  User(String completeName)
    {
        // Remove all no visible things
        completeName = completeName.replaceAll("\\s+","");

        // Check for Name with Comma Dilimeters
        if(completeName.contains(",")){

            // Splitting the names with comma dilimeter
            String[] separateName = completeName.split(",");
            // Storing first name and last name
            String fn = separateName[0];
            String ln = separateName[1];

        // converting first letter to upper case and applying it to setters
        this.setName(ln.substring(0, 1).toUpperCase() + ln.substring(1),fn.substring(0, 1).toUpperCase() + fn.substring(1));
        } else {
            // No comma dilimeter found, it means its a single string
            this.setName((completeName.substring(0, 1).toUpperCase().toString() + completeName.substring(1).toString()),"");
        }
    }

    // Set First and Last Name
    public void setName(String lastName,String firstName) {
        this.lastName = lastName;
        this.firstName = firstName;
    }

    // Return First and Last Name
    public String getName() {
        return lastName+", "+firstName;
    }

    @Override
    public String toString() {
        return getName();
    }
}
