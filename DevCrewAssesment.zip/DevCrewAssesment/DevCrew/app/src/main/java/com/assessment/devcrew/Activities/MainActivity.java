package com.assessment.devcrew.Activities;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import com.assessment.devcrew.Models.User;
import com.assessment.devcrew.R;
import com.assessment.devcrew.Utils.Contants;

import java.util.List;

/**
 * Created by mr on 03/03/16.
 */
public class MainActivity extends Activity {

    // private data members
    private List<User> userItems;
    private ArrayAdapter<User> itemsAdapter;
    private ListView lvItems;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // getting references of widgets
        lvItems = (ListView) findViewById(R.id.lvItems);
        // Initialising array list
        userItems = Contants.addDataToList();

        // setting adapter
        itemsAdapter = new ArrayAdapter<User>(this,
                android.R.layout.simple_list_item_1, userItems);

        // assigning adapter to listview
        lvItems.setAdapter(itemsAdapter);

        // Setup remove listener method call
        setupListViewListener();

    }

    // This method is primarily for Deleting an Item from ListView Upon Long Press
    private void setupListViewListener() {

        // Adding Listener to ListView
        lvItems.setOnItemLongClickListener(
                new AdapterView.OnItemLongClickListener() {
                    @Override
                    public boolean onItemLongClick(AdapterView<?> adapter,
                                                   View item, int pos, long id) {
                        // Remove the item within array at position
                        userItems.remove(pos);
                        // Refresh the adapter
                        itemsAdapter.notifyDataSetChanged();
                        // Return true consumes the long click event (marks it handled)
                        return true;
                    }

                });
    }

    // This is a Callback Method of Plus Sign Button
    public void onAddItemClicked(View v) {

        // This method will bring a popup that asks user
        // to enter new entry of first name and last name
        addMoreItemPopup();
    }


    // Method Invoked from Plus Button Callback
    private void addMoreItemPopup()
    {
        // Creating a Build Class
        AlertDialog.Builder builder = new AlertDialog.Builder(this);

        // Setting Title of Popup
        builder.setTitle("Dev Crew");

        // Setting Message
        builder.setMessage("Add New Name");

        // creating a EditText input field at run time
        final EditText inputField = new EditText(this);

        // Setting Hint of Text to be Added
        inputField.setHint("Your Good Name");

        // Assigning View of EditText to Popup
        builder.setView(inputField);

        // Adding Buttons to Popup
        builder.setPositiveButton("Add", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {

                // Method that will Process the String Entered by the User
                addNewName(inputField.getText().toString());

                // Resetting the Input Field with Empty String
                inputField.setText("");

            }
        });

        // Adding Negative Button to Cancel the Dialog
        builder.setNegativeButton("Cancel", null);

        // Once Configured, Show the Dialog to the User
        builder.create().show();
    }

    // Method that will Process the String Entered by User
    private  void addNewName(String itemText)
    {

        // If no name is entered
        if (itemText.length() <= 0) {
            Toast.makeText(getApplicationContext(), "No Name Entered", Toast.LENGTH_LONG).show();
            return;
        }

        // Creating a New Object of User with Entered Name
        User _userNew = new User(itemText);

        // Adding the User Object to ListView
        itemsAdapter.add(_userNew);
    }

}

